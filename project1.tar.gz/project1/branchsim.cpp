#include "branchsim.hpp"

/**
 * XXX: You are welcome to define and set any global classes and variables as needed.
 */

/**
 * Subroutine for initializing the branch predictor. You many add and initialize any global or heap
 * variables as needed.
 * XXX: You're responsible for completing this routine
 *
 * @param[in]   ptype       The type of branch predictor to simulate
 * @param[in]   num_entries The number of entries a PC is hashed into
 * @param[in]   counter_bits The number of bits per counter
 * @param[in]   history_bits The number of bits per history
 * @param[out]  p_stats     Pointer to the stats structure
 */
void setup_predictor(predictor_type ptype, int num_entries, int counter_bits, int history_bits,
                     branch_stats_t* p_stats) {
}

/**
 * Subroutine that queries the branch predictor for the branch direction.
 * XXX: You're responsible for completing this routine
 *
 * @param[in]   pc          The PC value of the branch instruction.
 * @param[out]  p_stats     Pointer to the stats structure
 *
 * @return                  Either TAKEN ('T'), or NOT_TAKEN ('N')
 */
branch_dir predict_branch(std::uint64_t pc, branch_stats_t* p_stats) {
    return TAKEN;
}

/**
 * Subroutine for updating the branch predictor. The branch predictor needs to be notified whether
 * it's prediction was right or wrong.
 * XXX: You're responsible for completing this routine
 *
 * @param[in]   pc          The PC value of the branch instruction.
 * @param[in]   actual      The actual direction of the branch
 * @param[in]   predicted   The predicted direction of the branch (from predict_branch)
 * @param[out]  p_stats     Pointer to the stats structure
 */
void update_predictor(std::uint64_t pc, branch_dir actual, branch_dir predicted, branch_stats_t* p_stats) {
}

/**
 * Subroutine for cleaning up any outstanding memory operations and calculating overall statistics.
 * XXX: You're responsible for completing this routine
 *
 * @param[out]  p_stats     Pointer to the statistics structure
 */
void complete_predictor(branch_stats_t *p_stats) {
}
